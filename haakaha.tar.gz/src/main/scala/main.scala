package FiveStage

object main {
    def main(args: Array[String]): Unit = {
        println("helo")
    }
}
